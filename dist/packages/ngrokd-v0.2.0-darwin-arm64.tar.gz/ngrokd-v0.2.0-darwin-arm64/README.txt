ngrokd - Forward Proxy Daemon for Kubernetes Bound Endpoints
==============================================================

Version: v0.2.0
Platform: darwin-arm64

Quick Install
-------------

Option 1: Using install script (recommended)
    sudo ./install.sh

Option 2: Manual installation
    chmod +x ngrokd ngrokctl
    sudo mv ngrokd /usr/local/bin/
    sudo mv ngrokctl /usr/local/bin/
    
    # Create config directory
    sudo mkdir -p /etc/ngrokd
    
    # Start daemon
    sudo ngrokd --config=/etc/ngrokd/config.yml &
    
    # Set API key
    ngrokctl set-api-key YOUR_NGROK_API_KEY

Quick Start
-----------

1. Install (see above)

2. Configure (if not using install script):
   sudo mkdir -p /etc/ngrokd
   # Create config.yml - see https://github.com/ishanj12/ngrokd

3. Start daemon:
   sudo nohup ngrokd --config=/etc/ngrokd/config.yml > ~/ngrokd.log 2>&1 &

4. Set API key:
   ngrokctl set-api-key YOUR_NGROK_API_KEY

5. Check status:
   ngrokctl status
   ngrokctl list

Uninstall
---------
    sudo ./uninstall.sh

Documentation
-------------
- GitHub: https://github.com/ishanj12/ngrokd
- README: https://github.com/ishanj12/ngrokd/blob/main/README.md
- macOS Guide: https://github.com/ishanj12/ngrokd/blob/main/MACOS.md
- Linux Guide: https://github.com/ishanj12/ngrokd/blob/main/LINUX.md

Requirements
------------
- ngrok API key (get from https://dashboard.ngrok.com/api)
- Bound endpoints created in ngrok
- sudo/root access
- Linux or macOS

Support
-------
Issues: https://github.com/ishanj12/ngrokd/issues
